#!/bin/bash

variable=""

if [ -z "$variable" ]; then
    echo "rien"
else
    echo "rempli"
fi
