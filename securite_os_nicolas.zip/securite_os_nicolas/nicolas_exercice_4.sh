#!/bin/bash

#exercice 4
grep -rl 'toto' . | xargs vim -p

