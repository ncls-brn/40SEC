#!/bin/bash

#exercice 7

if command -v "$1"; then
    CE="Oui"
else
    CE="Non"
fi

