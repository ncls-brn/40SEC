#!/bin/bash


#exercice 6
tr 'a-z' 'A-Z'
