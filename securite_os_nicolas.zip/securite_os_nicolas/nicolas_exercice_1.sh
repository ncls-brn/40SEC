#!/bin/bash

#exercice 1
cp fichier_v{1,2}.html.tar.gz





